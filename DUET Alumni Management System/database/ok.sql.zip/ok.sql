-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2018 at 02:21 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ok`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `oldpassword` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `oldpassword`) VALUES
(2, 'duet', 'duetcse');

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

CREATE TABLE `home` (
  `id` int(12) NOT NULL,
  `fullname` varchar(20) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(80) NOT NULL,
  `student_id` int(20) NOT NULL,
  `number` int(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `department` varchar(25) NOT NULL,
  `degree` varchar(25) NOT NULL,
  `passing_year` int(10) NOT NULL,
  `address` varchar(200) NOT NULL,
  `birth` varchar(20) NOT NULL,
  `orgination` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `paddress` varchar(300) NOT NULL,
  `blood` varchar(5) NOT NULL,
  `batch` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`id`, `fullname`, `name`, `email`, `password`, `student_id`, `number`, `gender`, `department`, `degree`, `passing_year`, `address`, `birth`, `orgination`, `designation`, `location`, `paddress`, `blood`, `batch`) VALUES
(23, 'sajib pal', 'sajib pal', 'sajibpal@gmail.com', '852369', 154045, 192640189, 'Male', 'CSE', 'B.SC', 2018, ' gazipur', '21/10/1995', 'DUET,', 'assitance engineer', 'DUET,gazipur', 'shariatpur', '', ''),
(24, 'fdsf', 'dsfsdfsd', 'fgdgdfgg@gmail.com', '741258', 154066, 746768776, 'Male', 'CSE', 'B.SC', 2014, ' ghfdhg', '746768776', 'dfg', 'hghfgh', 'fgfhf', 'ghfgh', 'AB+', '2nd'),
(25, 'bisu das', 'bisu das', 'basu@gmail.com', '789456', 154046, 1988489489, 'male', 'EEE', '', 0, '', '', 'desko', 'engineer', 'dinajpur', '', '', ''),
(26, 'raton pal', 'raton', '', '', 124026, 1984489, 'male', 'CSE', 'B.sc', 2018, '', '', '', '', '', '', '', '12');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(20) NOT NULL,
  `month` varchar(10) NOT NULL,
  `day` int(10) NOT NULL,
  `post` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `month`, `day`, `post`) VALUES
(1, 'Dec', 14, 'GMAE ON'),
(2, 'Mar', 20, 'good'),
(3, 'May', 23, 'kool'),
(4, 'Jan', 15, 'cricket'),
(5, 'Dec', 14, 'play game'),
(6, 'Dec', 15, 'new enent'),
(7, 'Dec', 15, 'football game '),
(8, 'Dec', 15, 'game on');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(20) NOT NULL,
  `student_id` int(20) NOT NULL,
  `checknumber` varchar(30) NOT NULL,
  `amount` int(25) NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `student_id`, `checknumber`, `amount`, `date`) VALUES
(1, 154145, '45784-498488', 50000, '2018-12-01'),
(2, 154778, '7877786', 900, '2018-11-26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home`
--
ALTER TABLE `home`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `home`
--
ALTER TABLE `home`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
